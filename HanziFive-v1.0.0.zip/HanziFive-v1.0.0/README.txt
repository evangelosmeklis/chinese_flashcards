# HanziFive - Chinese Flashcards

## How to Run

### Windows
Double-click the HanziFive.bat file to start the application.

### macOS / Linux
Double-click the HanziFive.sh file to start the application. If it doesn't run directly, open Terminal and run:
```
chmod +x HanziFive.sh
./HanziFive.sh
```

## About
HanziFive is a modern Chinese flashcard application to help you learn and practice Chinese characters.

Enjoy learning Chinese!
